version = (0, 7)
version_string = '.'.join(['%d' % i for i in version])
