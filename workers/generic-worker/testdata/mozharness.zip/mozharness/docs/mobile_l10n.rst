mobile_l10n module
==================

.. automodule:: mobile_l10n
    :members:
    :undoc-members:
    :show-inheritance:
