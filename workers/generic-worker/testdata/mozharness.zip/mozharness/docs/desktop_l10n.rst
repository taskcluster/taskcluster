desktop_l10n module
===================

.. automodule:: desktop_l10n
    :members:
    :undoc-members:
    :show-inheritance:
