config = {
    "selfserve_url": "https://secure-pub-build.allizom.org/buildapi/self-serve",
}
