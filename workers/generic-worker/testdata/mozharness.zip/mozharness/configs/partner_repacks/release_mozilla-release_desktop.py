config = {
    "appName": "Firefox",
    "log_name": "partner_repack",
    "repack_manifests_url": "git@github.com:mozilla-partners/repack-manifests.git",
    "repo_file": "https://raw.githubusercontent.com/mozilla/git-repo/master/repo",
}
