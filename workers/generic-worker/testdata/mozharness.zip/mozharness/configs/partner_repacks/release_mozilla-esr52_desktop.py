config = {
    "appName": "Firefox",
    "log_name": "partner_repack",
    "repack_manifests_url": "https://github.com/mozilla-partners/mozilla-sha1-manifest",
    "repo_file": "https://raw.githubusercontent.com/mozilla/git-repo/master/repo",
}
