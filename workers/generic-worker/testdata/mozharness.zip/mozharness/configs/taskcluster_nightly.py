config = {
    'nightly_build': True,
    'taskcluster_nightly': True,
}

