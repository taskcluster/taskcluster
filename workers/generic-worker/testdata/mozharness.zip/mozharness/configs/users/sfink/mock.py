config = {
     "mock_target": "mozilla-centos6-x86_64",
}
