config = {
  'build_command': "build.shell",
  'expect_file': "expect.shell.json",
}
