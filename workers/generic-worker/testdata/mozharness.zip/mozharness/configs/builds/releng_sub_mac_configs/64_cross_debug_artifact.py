config = {
    'perfherder_extra_options': ['artifact'],
    'src_mozconfig': 'browser/config/mozconfigs/macosx64/debug-artifact',
}
