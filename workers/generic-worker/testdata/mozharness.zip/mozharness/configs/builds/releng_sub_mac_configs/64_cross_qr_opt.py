import os

MOZ_OBJDIR = 'obj-firefox'

config = {
    'src_mozconfig': 'browser/config/mozconfigs/macosx64/opt-qr',
}
