import os
import sys

config = {
    'base_name': 'WINNT_5.2_%(branch)s_Artifact_build',
    'src_mozconfig': 'browser/config/mozconfigs/win32/debug-artifact',
}
