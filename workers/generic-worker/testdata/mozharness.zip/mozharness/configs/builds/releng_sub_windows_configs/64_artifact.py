import os
import sys

config = {
    'base_name': 'WINNT_6.1_x86-64_%(branch)s_Artifact_build',
    'src_mozconfig': 'browser/config/mozconfigs/win64/artifact',
}
