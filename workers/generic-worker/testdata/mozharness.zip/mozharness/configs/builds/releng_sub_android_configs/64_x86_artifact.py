config = {
    'base_name': 'Android 4.2 x86 %(branch)s Artifact build',
    'stage_platform': 'android-x86',
    'publish_nightly_en_US_routes': False,
    'build_type': 'x86-opt',
    'src_mozconfig': 'mobile/android/config/mozconfigs/android-x86/nightly-artifact',
    'tooltool_manifest_src': 'mobile/android/config/tooltool-manifests/android-x86/releng.manifest',
}
