import os

MOZ_OBJDIR = 'obj-firefox'

config = {
    'src_mozconfig': 'browser/config/mozconfigs/linux32/opt-qr',
}
